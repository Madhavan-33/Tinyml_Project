/*
 * TinyML Anomaly Detector - Arduino Sketch
 * Compatibility: Arduino Nano 33 BLE / ESP32 / Teensy 4.0 / STM32 (via STM32Core)
 */

#include "model_config.h"
#include "model_data.h"

// Note: Ensure TensorFlowLite_ESP32 or Harvard_TFLiteMicro library is installed in Arduino IDE
#include <TensorFlowLite.h>
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"

constexpr int kTensorArenaSize = 10 * 1024;
alignas(16) static uint8_t tensor_arena[kTensorArenaSize];

const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
TfLiteTensor* output = nullptr;

void setup() {
    Serial.begin(115200);
    while (!Serial && millis() < 3000); // Wait for serial console

    Serial.println("=========================================");
    Serial.println("🚀 TinyML Anomaly Detector Booting (Arduino)");
    Serial.println("=========================================");

    model = tflite::GetModel(g_model);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        Serial.println("❌ Model schema mismatch error!");
        return;
    }

    static tflite::AllOpsResolver resolver;
    static tflite::MicroInterpreter static_interpreter(model, resolver, tensor_arena, kTensorArenaSize);
    interpreter = &static_interpreter;

    TfLiteStatus allocate_status = interpreter->AllocateTensors();
    if (allocate_status != kTfLiteOk) {
        Serial.println("❌ AllocateTensors() failed!");
        return;
    }

    input = interpreter->input(0);
    output = interpreter->output(0);
    Serial.println("✅ TinyML Interpreter initialized successfully!");
}

unsigned long sample_count = 0;

void loop() {
    sample_count++;
    float current_raw[NUM_FEATURES];

    // Read or simulate sensor values
    for (int i = 0; i < NUM_FEATURES; i++) {
        float noise = ((float)random(-100, 100) / 100.0f) * (FEATURE_STDS[i] * 0.3f);
        current_raw[i] = FEATURE_MEANS[i] + noise;
    }

    // Periodic anomaly injection for demonstration
    if (sample_count % 15 == 0) {
        current_raw[0] += FEATURE_STDS[0] * 4.0f;
    }

    // Normalize features
    for (int i = 0; i < NUM_FEATURES; i++) {
        float std_val = (FEATURE_STDS[i] == 0.0f) ? 1.0f : FEATURE_STDS[i];
        input->data.f[i] = (current_raw[i] - FEATURE_MEANS[i]) / std_val;
    }

    // Invoke Inference
    TfLiteStatus invoke_status = interpreter->Invoke();
    if (invoke_status != kTfLiteOk) {
        Serial.println("❌ Inference Invoke failed!");
        delay(1000);
        return;
    }

    // Compute Reconstruction Loss (MSE)
    float mse = 0.0f;
    for (int i = 0; i < NUM_FEATURES; i++) {
        float diff = input->data.f[i] - output->data.f[i];
        mse += diff * diff;
    }
    mse /= (float)NUM_FEATURES;

    bool is_anomaly = (mse > ANOMALY_THRESHOLD);
    float health = max(0.0f, min(100.0f, 100.0f - (mse / (ANOMALY_THRESHOLD + 1e-5f)) * 25.0f));

    // Structured Serial Telemetry Output matching Streamlit PySerial parser
    Serial.print("[MCU_TELEMETRY] SAMPLE=");
    Serial.print(sample_count);
    Serial.print(", MSE=");
    Serial.print(mse, 6);
    Serial.print(", STATUS=");
    Serial.print(is_anomaly ? "ANOMALY" : "NORMAL");
    Serial.print(", HEALTH=");
    Serial.print(health, 2);
    Serial.print(", V0=");
    Serial.print(current_raw[0], 4);
    Serial.print(", V1=");
    Serial.println(current_raw[1], 4);

    delay(500);
}
