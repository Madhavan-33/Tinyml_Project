# 🚀 Physical Microcontroller TinyML Model Deployment Guide

This package contains everything needed to run your trained TensorFlow Lite Micro Anomaly Detector on a **Physical Microcontroller** or inside the **Renode Emulator**.

---

## 📁 Included Files:
1. `model_data.h` - C byte array representation of your trained `.tflite` model.
2. `model_config.h` - Feature scaling means, standard deviations, and anomaly threshold.
3. `main_tflm.cpp` - C++ main application entry point with TFLite Micro interpreter runtime loop.
4. `Arduino_Sketch.ino` - Complete ready-to-flash sketch for Arduino IDE (ESP32 / Nano 33 BLE / Teensy).
5. `platformio.ini` - PlatformIO build settings for STM32, ESP32, and nRF52.
6. `Makefile` - GCC ARM Cortex-M cross-compilation Makefile.
7. `emulate_stm32.resc` - Renode simulation script for testing without physical hardware.

---

## 🔌 Deploying to Physical Microcontrollers

### Option A: Arduino IDE (ESP32 / Arduino Nano 33 BLE / STM32)
1. Open `Arduino_Sketch.ino` in Arduino IDE.
2. Copy `model_data.h` and `model_config.h` into the same folder as the sketch.
3. Install **TensorFlowLite_ESP32** or **Harvard_TFLiteMicro** from Library Manager.
4. Select your board and COM port.
5. Click **Upload** (Ctrl+U).
6. Open **Serial Monitor** at **115200 baud** to view live inference logs!

### Option B: PlatformIO (VS Code)
1. Open this folder in VS Code with PlatformIO extension installed.
2. Select your environment (`stm32f407_discovery`, `esp32dev`, or `nano33ble`).
3. Click **Build** and **Upload**.

### Option C: STM32CubeProgrammer / ST-Link CLI
Build using ARM GCC toolchain and flash via ST-Link:
```bash
make
st-flash write firmware.bin 0x8000000
```

### Option D: ESP32 Direct Flashing (`esptool.py`)
```bash
esptool.py --chip esp32 --port COM3 --baud 921600 write_flash -z 0x10000 firmware.bin
```

---

## 📡 Connecting to Streamlit UI
Once flashed onto your physical microcontroller:
1. Plug the microcontroller into your computer via USB.
2. Open the Streamlit App -> Go to **Tab 3: 🔌 Physical Microcontroller Connection**.
3. Select your microcontroller's **COM Port** (e.g. `COM3`, `/dev/ttyUSB0`) and **115200 Baud**.
4. Click **▶️ Read Serial Stream Packets** or enable **Continuous Live Auto-Stream**!
