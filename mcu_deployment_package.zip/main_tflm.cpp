/*
 * TinyML Anomaly Detector Firmware Template for ARM Cortex-M / Renode
 * Integrates TFLite Micro, model_data.h, and model_config.h
 * Continuous Emulation Stream with Structured Serial UART Output
 */

#include <stdio.h>
#include <stdlib.h>
#include "model_config.h"
#include "model_data.h"

// TensorFlow Lite for Microcontrollers Headers
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
#include "tensorflow/lite/schema/schema_generated.h"

// Allocate 10KB memory arena for model tensor operations
constexpr int kTensorArenaSize = 10 * 1024;
alignas(16) static uint8_t tensor_arena[kTensorArenaSize];

// Simple LCG random float generator [0.0, 1.0] for embedded environments
static float rand_float() {
    static unsigned int seed = 12345;
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return (float)seed / (float)0x7fffffff;
}

int main() {
    printf("=== TinyML Anomaly Detector Booting on Renode MCU ===\n");
    printf("Configured NUM_FEATURES: %d | Threshold: %.6f\n", NUM_FEATURES, ANOMALY_THRESHOLD);

    // 1. Load TFLite Model from C Byte Array
    const tflite::Model* model = tflite::GetModel(g_model);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        printf("ERROR: Model schema version mismatch!\n");
        return -1;
    }

    // 2. Setup Op Resolver (Register ops required by Autoencoder)
    tflite::MicroMutableOpResolver<5> micro_op_resolver;
    micro_op_resolver.AddFullyConnected();
    micro_op_resolver.AddRelu();
    micro_op_resolver.AddReshape();
    micro_op_resolver.AddQuantize();
    micro_op_resolver.AddDequantize();

    // 3. Build Micro Interpreter
    tflite::MicroInterpreter interpreter(model, micro_op_resolver, tensor_arena, kTensorArenaSize);

    // Allocate memory from tensor_arena for input/output tensors
    TfLiteStatus allocate_status = interpreter.AllocateTensors();
    if (allocate_status != kTfLiteOk) {
        printf("ERROR: AllocateTensors() failed!\n");
        return -1;
    }

    TfLiteTensor* input = interpreter.input(0);
    TfLiteTensor* output = interpreter.output(0);

    printf(">>> STARTING REAL-TIME SENSOR EMULATION LOOP <<<\n");

    float current_raw[NUM_FEATURES];
    // Set default baseline values from FEATURE_MEANS
    for (int i = 0; i < NUM_FEATURES; i++) {
        current_raw[i] = FEATURE_MEANS[i];
    }

    int sample_count = 0;

    // Emulation loop - process telemetry cycles
    while (1) {
        sample_count++;

        // Generate synthetic signal with slight Gaussian-like noise:
        // Inject periodic fault/anomaly every ~18-20 samples
        bool inject_anomaly = (sample_count % 18 == 0 || sample_count % 19 == 0);

        for (int i = 0; i < NUM_FEATURES; i++) {
            float noise = (rand_float() - 0.5f) * (FEATURE_STDS[i] * 0.4f);
            current_raw[i] = FEATURE_MEANS[i] + noise;

            if (inject_anomaly) {
                // Add significant deviation (3-5 sigma spike) to feature 0 and 1
                if (i == 0 || i == 1) {
                    current_raw[i] += FEATURE_STDS[i] * (3.5f + rand_float() * 2.0f);
                }
            }
        }

        // 4. Preprocess Features (Normalize with FEATURE_MEANS and FEATURE_STDS)
        for (int i = 0; i < NUM_FEATURES; i++) {
            float std_val = (FEATURE_STDS[i] == 0.0f) ? 1.0f : FEATURE_STDS[i];
            input->data.f[i] = (current_raw[i] - FEATURE_MEANS[i]) / std_val;
        }

        // 5. Run Model Inference
        TfLiteStatus invoke_status = interpreter.Invoke();
        if (invoke_status != kTfLiteOk) {
            printf("ERROR: Inference Invoke failed!\n");
            break;
        }

        // 6. Calculate Reconstruction Loss (MSE)
        float mse = 0.0f;
        for (int i = 0; i < NUM_FEATURES; i++) {
            float diff = input->data.f[i] - output->data.f[i];
            mse += diff * diff;
        }
        mse /= (float)NUM_FEATURES;

        // Health Index calculation (0 - 100%)
        float ratio = mse / (ANOMALY_THRESHOLD + 1e-6f);
        float health_index = 100.0f - (ratio * 25.0f);
        if (health_index < 0.0f) health_index = 0.0f;
        if (health_index > 100.0f) health_index = 100.0f;

        const char* status_str = (mse > ANOMALY_THRESHOLD) ? "ANOMALY" : "NORMAL";

        // Output structured serial line for PySerial / Streamlit parsing
        printf("[RENODE_MCU] SAMPLE=%d, MSE=%.6f, STATUS=%s, HEALTH=%.2f, V0=%.4f, V1=%.4f\n",
               sample_count, mse, status_str, health_index, current_raw[0], (NUM_FEATURES > 1 ? current_raw[1] : 0.0f));

        // Delay loop for MCU execution cycle
        for (volatile int d = 0; d < 100000; d++);
    }

    return 0;
}

