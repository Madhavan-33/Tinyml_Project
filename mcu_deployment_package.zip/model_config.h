/*
 * Auto-Generated TinyML Model Configuration Header
 * Target: STM32 Microcontroller / ARM Cortex-M Firmware
 */

#ifndef MODEL_CONFIG_H
#define MODEL_CONFIG_H

#define NUM_FEATURES 4
#define ANOMALY_THRESHOLD 0.334729f

/*
 * Model Feature Order:
 * temperature, vibration, temperature_volatility, vibration_volatility
 */

static const float FEATURE_MEANS[4] = { 25.028998f, 0.507084f, 0.055356f, 0.185500f };
static const float FEATURE_STDS[4] = { 1.468089f, 0.099696f, 0.019738f, 0.075910f };

#endif /* MODEL_CONFIG_H */
